import React from 'react';
import { Header } from './components/Header';
import { SafetyResources } from './components/SafetyResources';
import { IncidentReport } from './components/IncidentReport';
import { EmergencyButton } from './components/EmergencyButton';

function App() {
  return (
    <div className="min-h-screen bg-gray-50">
      <Header />
      
      {/* Hero Section */}
      <section className="relative bg-purple-600 text-white py-20">
        <div className="container mx-auto px-4">
          <div className="max-w-3xl">
            <h1 className="text-4xl md:text-5xl font-bold mb-6">
              Your Safety Is Our Priority
            </h1>
            <p className="text-xl mb-8">
              Access immediate help, report incidents, and find safety resources. We're here to support and protect you 24/7.
            </p>
            <button className="bg-white text-purple-600 px-8 py-3 rounded-md font-semibold text-lg hover:bg-purple-100 transition-colors">
              Get Started
            </button>
          </div>
        </div>
        <div 
          className="absolute inset-0 z-0 opacity-10"
          style={{
            backgroundImage: 'url("https://images.unsplash.com/photo-1573164713714-d95e436ab8d6?auto=format&fit=crop&q=80")',
            backgroundSize: 'cover',
            backgroundPosition: 'center'
          }}
        ></div>
      </section>

      {/* Safety Resources Section */}
      <section id="resources" className="py-16 bg-white">
        <div className="container mx-auto px-4">
          <h2 className="text-3xl font-bold text-center mb-12 text-gray-800">
            Safety Resources & Support
          </h2>
          <SafetyResources />
        </div>
      </section>

      {/* Incident Report Section */}
      <section id="report" className="py-16 bg-gray-50">
        <div className="container mx-auto px-4">
          <h2 className="text-3xl font-bold text-center mb-12 text-gray-800">
            Report an Incident
          </h2>
          <IncidentReport />
        </div>
      </section>

      {/* Emergency Button */}
      <EmergencyButton />
    </div>
  );
}

export default App;