import React from 'react';
import { Shield, Phone, MapPin, BookOpen } from 'lucide-react';

const resources = [
  {
    title: 'Emergency Contacts',
    icon: <Phone className="w-6 h-6" />,
    content: 'Police: 911\nWomen\'s Helpline: 1-800-799-SAFE\nEmergency SMS: Text HOME to 741741'
  },
  {
    title: 'Safe Locations',
    icon: <MapPin className="w-6 h-6" />,
    content: 'Find verified safe spaces, police stations, and women\'s shelters near you.'
  },
  {
    title: 'Safety Tips',
    icon: <Shield className="w-6 h-6" />,
    content: 'Learn essential self-defense techniques and safety protocols for various situations.'
  },
  {
    title: 'Educational Resources',
    icon: <BookOpen className="w-6 h-6" />,
    content: 'Access guides, workshops, and training materials on personal safety and awareness.'
  }
];

export const SafetyResources = () => {
  return (
    <div className="grid grid-cols-1 md:grid-cols-2 gap-6 p-6">
      {resources.map((resource, index) => (
        <div
          key={index}
          className="bg-white p-6 rounded-lg shadow-md hover:shadow-lg transition-shadow"
        >
          <div className="flex items-center gap-3 mb-4">
            <div className="text-purple-600">{resource.icon}</div>
            <h3 className="text-xl font-semibold text-gray-800">{resource.title}</h3>
          </div>
          <p className="text-gray-600 whitespace-pre-line">{resource.content}</p>
        </div>
      ))}
    </div>
  );
};