import React from 'react';
import { Shield, Menu } from 'lucide-react';

export const Header = () => {
  return (
    <header className="bg-purple-600 text-white shadow-lg">
      <div className="container mx-auto px-4 py-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Shield className="w-8 h-8" />
            <h1 className="text-2xl font-bold">SafeGuardian</h1>
          </div>
          <nav className="hidden md:flex items-center gap-6">
            <a href="#home" className="hover:text-purple-200 transition-colors">Home</a>
            <a href="#resources" className="hover:text-purple-200 transition-colors">Resources</a>
            <a href="#report" className="hover:text-purple-200 transition-colors">Report Incident</a>
            <button className="bg-white text-purple-600 px-4 py-2 rounded-md font-semibold hover:bg-purple-100 transition-colors">
              Get Help
            </button>
          </nav>
          <button className="md:hidden">
            <Menu className="w-6 h-6" />
          </button>
        </div>
      </div>
    </header>
  );
};