import React, { useState } from 'react';
import { FileText } from 'lucide-react';

export const IncidentReport = () => {
  const [formData, setFormData] = useState({
    type: '',
    location: '',
    description: '',
    date: '',
    time: ''
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    // In a real app, this would submit to a backend
    console.log('Incident reported:', formData);
    alert('Thank you for reporting. Appropriate authorities would be notified.');
  };

  return (
    <div className="bg-white p-6 rounded-lg shadow-md max-w-2xl mx-auto">
      <div className="flex items-center gap-3 mb-6">
        <FileText className="w-6 h-6 text-purple-600" />
        <h2 className="text-2xl font-semibold text-gray-800">Report an Incident</h2>
      </div>
      <form onSubmit={handleSubmit} className="space-y-4">
        <div>
          <label className="block text-gray-700 mb-2">Incident Type</label>
          <select
            className="w-full p-2 border rounded-md focus:ring-2 focus:ring-purple-500"
            value={formData.type}
            onChange={(e) => setFormData({ ...formData, type: e.target.value })}
            required
          >
            <option value="">Select type</option>
            <option value="harassment">Harassment</option>
            <option value="stalking">Stalking</option>
            <option value="assault">Assault</option>
            <option value="other">Other</option>
          </select>
        </div>
        <div>
          <label className="block text-gray-700 mb-2">Location</label>
          <input
            type="text"
            className="w-full p-2 border rounded-md focus:ring-2 focus:ring-purple-500"
            value={formData.location}
            onChange={(e) => setFormData({ ...formData, location: e.target.value })}
            required
          />
        </div>
        <div>
          <label className="block text-gray-700 mb-2">Date</label>
          <input
            type="date"
            className="w-full p-2 border rounded-md focus:ring-2 focus:ring-purple-500"
            value={formData.date}
            onChange={(e) => setFormData({ ...formData, date: e.target.value })}
            required
          />
        </div>
        <div>
          <label className="block text-gray-700 mb-2">Time</label>
          <input
            type="time"
            className="w-full p-2 border rounded-md focus:ring-2 focus:ring-purple-500"
            value={formData.time}
            onChange={(e) => setFormData({ ...formData, time: e.target.value })}
            required
          />
        </div>
        <div>
          <label className="block text-gray-700 mb-2">Description</label>
          <textarea
            className="w-full p-2 border rounded-md focus:ring-2 focus:ring-purple-500 h-32"
            value={formData.description}
            onChange={(e) => setFormData({ ...formData, description: e.target.value })}
            required
          ></textarea>
        </div>
        <button
          type="submit"
          className="w-full bg-purple-600 text-white py-2 rounded-md hover:bg-purple-700 transition-colors"
        >
          Submit Report
        </button>
      </form>
    </div>
  );
};