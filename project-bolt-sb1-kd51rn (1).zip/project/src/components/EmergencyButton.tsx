import React from 'react';
import { Phone, AlertCircle } from 'lucide-react';

export const EmergencyButton = () => {
  const handleEmergency = () => {
    // In a real app, this would trigger emergency protocols
    alert('Emergency services would be contacted and trusted contacts notified');
  };

  return (
    <button
      onClick={handleEmergency}
      className="fixed bottom-6 right-6 bg-red-600 text-white p-4 rounded-full shadow-lg hover:bg-red-700 transition-colors flex items-center gap-2 animate-pulse"
    >
      <Phone className="w-6 h-6" />
      <span className="font-bold">Emergency</span>
      <AlertCircle className="w-6 h-6" />
    </button>
  );
};